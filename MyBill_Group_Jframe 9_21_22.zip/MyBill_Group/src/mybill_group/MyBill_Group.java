 /*
Noah Kolb
Brandon Strother
09/21/22
Bill calculator that will use JOptionPane
CSC-251
*/
package mybill_group;

import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyBill_Group
{
    public static double CreditHours = 0.0;
    public static String ClassName;
    
    public static void main(String[] args)
    {
        String studentName, creditInput,tuitionType,classInput, finantialAid,classData="\n", sinPluCla="class"/*test*/;
        int numClasses = 0, counter, creditNum = 0, creditPrice = 0, data=0;
        double tuition, total;
        //classes
        String[] classChoice = new String[5];
        classChoice[0] = "CSC";
        classChoice[1] = "DBA";
        classChoice[2] = "CTI";
        classChoice[3] = "CTS";
        classChoice[4] = "CIS";
        /*constant values*/
        int activityFee = 35, campusAccess = 15, techFee = 16;
        studentName = JOptionPane.showInputDialog("Please enter your name");
        finantialAid= JOptionPane.showInputDialog("Are you receiving Finantial Aid. yes or no");       
        tuitionType = JOptionPane.showInputDialog("Are you In-State. yes or no");
        if (tuitionType.toUpperCase().equals("YES"))
        {
            creditPrice = 76;
        }
        else if (tuitionType.toUpperCase().equals("NO"))
        {
            creditPrice = 268;
        }
        
        
        
        try{
            classInput = JOptionPane.showInputDialog("How many classes will you take this semester?");         
            numClasses = Integer.parseInt(classInput);
            if (numClasses > 1)
            {sinPluCla = "classes";
            }
            else if (numClasses <= 1)
            {sinPluCla = "class";
            }
            for (counter = 0; numClasses > counter; counter++)
            {
            classData = classData + JOptionPane.showInputDialog(null, "Choose your class", "Class Selection", JOptionPane.QUESTION_MESSAGE, null, classChoice, "CIS") + "\n";
            //new Class_Data().setVisible(true);
            creditInput = JOptionPane.showInputDialog("How many credit hours is that class worth?");
            creditNum = creditNum + Integer.parseInt(creditInput);
            
            }
                
        }
        catch(Exception num){
            JOptionPane.showMessageDialog(null,"Please enter a number");
        }       
        
        if (CreditHours > 16)
        {
            CreditHours = 16;
        }
        tuition = creditPrice * CreditHours;
        total = activityFee + campusAccess + techFee + tuition;
        if (finantialAid.toUpperCase().equals("YES"))
        {
           total = 0;
        }
        JOptionPane.showMessageDialog(null, studentName + " your total for this semester is $"+ String.format("%.2f", total));
        
        JOptionPane.showMessageDialog(null, "Hello "+ studentName + ",\n"
                +"Your taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "Your total credit hours is " + creditNum + "\n" +
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid " + finantialAid + "\n" + 
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData );
      
        try {
            print(studentName, sinPluCla, finantialAid, classData, creditNum, numClasses,activityFee, campusAccess, techFee, tuition, total);
        } catch (IOException ex) {
            Logger.getLogger(MyBill_Group.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void SetFormInfo(String className, double creditHours){
        ClassName = className;
        CreditHours += creditHours;
    }
    
    public static void print(String studentName,String sinPluCla,String finantialAid, String classData,int creditNum, int numClasses, int activityFee,int campusAccess,int techFee,double tuition, double total) throws IOException{
        PrintWriter outputfile = new PrintWriter(studentName+"Tuition.txt", "UTF-8");
        outputfile.println("Hello "+ studentName + ",\n"
                +"You're taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "Your total credit hours is " + creditNum + "\n" +
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid " + finantialAid + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData);
        outputfile.close();
    }   
}