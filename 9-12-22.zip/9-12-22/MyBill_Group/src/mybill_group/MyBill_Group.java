/*
9/7/22 update
Noah kolb
 */
package mybill_group;

import javax.swing.JOptionPane;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyBill_Group
{
    public static void main(String[] args)
    {
        String studentName, creditInput,tuitionType,classInput, finantialAid, sinPluCla="class"/*test*/;
        int numClasses = 0, counter, creditNum, creditPrice = 0, tuition;
        double total;
        /*constant values*/
        int activityFee = 35, campusAccess = 15, techFee = 16;
        
        studentName = JOptionPane.showInputDialog("Please enter your name");
        finantialAid= JOptionPane.showInputDialog("Are you receiving Finantial Aid. yes or no");
        
        tuitionType = JOptionPane.showInputDialog("Are you In-State. yes or no");
        if (tuitionType.toUpperCase().equals("YES"))
        {
            creditPrice = 76;
        }
        else if (tuitionType.toUpperCase().equals("NO"))
        {
            creditPrice = 268;
        }
        
        
        
        try{
            classInput = JOptionPane.showInputDialog("How many classes will you take this semester?");         
            numClasses = Integer.parseInt(classInput);
            if (numClasses > 1)
            {sinPluCla = "classes";
            }
            else if (numClasses <= 1)
            {sinPluCla = "class";
            }
        }
        catch(Exception num){
            JOptionPane.showMessageDialog(null,"Please enter a number");
        }
        /*for (counter = 0; numClasses > counter; counter++)
        {
           test = JOptionPane.showInputDialog("enter number");
        }*/
        
        
        
        creditInput = JOptionPane.showInputDialog("How many credit hours are scheduled this semester?");
        creditNum = Integer.parseInt(creditInput);
        if (creditNum > 16)
        {
            creditNum = 16;
        }
        tuition = creditPrice * creditNum;
        total = activityFee + campusAccess + techFee + tuition;
        if (finantialAid.toUpperCase().equals("YES"))
        {
           total = 0;
        }
        JOptionPane.showMessageDialog(null, studentName + " your total for this semester is $"+ String.format("%.2f", total));
        
        JOptionPane.showMessageDialog(null, "Hello "+ studentName + ",\n"
                +"Your taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total));
      
        try {
            print(studentName, sinPluCla,numClasses,activityFee, campusAccess, techFee, tuition, total);
        } catch (IOException ex) {
            Logger.getLogger(MyBill_Group.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void print(String studentName,String sinPluCla,int numClasses, int activityFee,int campusAccess,int techFee,int tuition, double total) throws IOException{
        PrintWriter outputfile = new PrintWriter(studentName+"Tuition.txt", "UTF-8");
        outputfile.println("Hello "+ studentName + ",\n"
                +"Your taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total));
        outputfile.close();
    }
  
    
}
