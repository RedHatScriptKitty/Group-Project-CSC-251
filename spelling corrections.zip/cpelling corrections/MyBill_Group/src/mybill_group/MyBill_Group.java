/*
9/7/22 update
Noah kolb
 */
package mybill_group;

import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyBill_Group
{
    public static void main(String[] args)
    {
        String studentName, creditInput,tuitionType,classInput, financialAid,financialAidNum,classData="\n", sinPluCla="class"/*test*/;
        int numClasses = 0, counter, creditNum=0, creditPrice = 0, tuition, creditDisplay=0, data=0,finantialAidparse=0;
        double total;
        //classes
        String[] classChoice = new String[5];
        classChoice[0] = "CSC";
        classChoice[1] = "DBA";
        classChoice[2] = "CTI";
        classChoice[3] = "CTS";
        classChoice[4] = "CIS";
        /*constant values*/
        int activityFee = 35, campusAccess = 15, techFee = 16;
        studentName = JOptionPane.showInputDialog("Please enter your name");
        financialAid= JOptionPane.showInputDialog("Are you receiving financial Aid. yes or no");       
        if (financialAid.toUpperCase().equals("YES"))
        {
            financialAidNum= JOptionPane.showInputDialog("How much financial aid are you recieving?");
            finantialAidparse = Integer.parseInt(financialAidNum);
        }
        
        tuitionType = JOptionPane.showInputDialog("Are you In-State. yes or no");
        if (tuitionType.toUpperCase().equals("YES"))
        {
            creditPrice = 76;
        }
        else if (tuitionType.toUpperCase().equals("NO"))
        {
            creditPrice = 268;
        }
        
        
        
        try{
            classInput = JOptionPane.showInputDialog("How many classes will you take this semester?");         
            numClasses = Integer.parseInt(classInput);
            if (numClasses > 1)
            {sinPluCla = "classes";
            }
            else if (numClasses <= 1)
            {sinPluCla = "class";
            }
            while (data != numClasses)
            {
            classData = classData + JOptionPane.showInputDialog(null, "Choose your class", "Class Selection", JOptionPane.QUESTION_MESSAGE, null, classChoice, "CIS") + "\n";
            creditInput = JOptionPane.showInputDialog("How many credits is this class worth?");
            creditNum = creditNum + Integer.parseInt(creditInput);
            creditDisplay = creditNum;
            data = data+1;
            }
                
        }
        catch(Exception num){
            JOptionPane.showMessageDialog(null,"Please enter a number");
        }
        /*for (counter = 0; numClasses > counter; counter++)
        {
           test = JOptionPane.showInputDialog("enter number");
        }*/
        
        if (creditNum > 16)
        {
            creditNum = 16;
        }
        tuition = creditPrice * creditNum;
        total = activityFee + campusAccess + techFee + tuition-financialAidparse;
        
        JOptionPane.showMessageDialog(null, studentName + " your total for this semester is $"+ String.format("%.2f", total));
        
        JOptionPane.showMessageDialog(null, "Hello "+ studentName + ",\n"
                +"Your taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "You have " + creditDisplay + " credits scheduled for this semester" + "\n" + 
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid $" + financialAidparse + "\n" + 
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData );
      
        try {
            print(studentName, sinPluCla, financialAidparse, classData, creditDisplay, numClasses,activityFee, campusAccess, techFee, tuition, total);
        } catch (IOException ex) {
            Logger.getLogger(MyBill_Group.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void print(String studentName,String sinPluCla,int financialAidparse, String classData,int creditDisplay, int numClasses, int activityFee,int campusAccess,int techFee,int tuition, double total) throws IOException{
        PrintWriter outputfile = new PrintWriter(studentName+"Tuition.txt", "UTF-8");
        outputfile.println("Hello "+ studentName + ",\n"
                +"You're taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "A break down of your total " + "\n" +
                "You have " + creditDisplay + " credits scheduled for this semester" + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid " + financialAidparse + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData);
        outputfile.close();
    }
  
    
}
