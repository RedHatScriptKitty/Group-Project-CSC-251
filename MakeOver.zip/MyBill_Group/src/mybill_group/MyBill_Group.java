 /*
Noah Kolb
Brandon Strother
09/21/22
Bill calculator that will use JOptionPane
CSC-251
*/
package mybill_group;

import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyBill_Group
{
    public static double CreditHours = 0.0;
    public static String ClassName;
    public static String name2;
    public static String state2;
    public static String aid2;
    public static double classes2 = 0.0;
    
    
    public static void main(String[] args)
    {
        new Data().setVisible(true);
        String finantialAid,classData="\n", sinPluCla="class"/*test*/;
        int numClasses = 0, counter, creditNum = 0, creditPrice = 0, data=0;
        double tuition, total;
        //classes
        String[] classChoice = new String[5];
      
        /*constant values*/
        int activityFee = 35, campusAccess = 15, techFee = 16;
  
        if (state2.toUpperCase().equals("in-state"))
        {
            creditPrice = 76;
        }
        else if (state2.toUpperCase().equals("out-of-state"))
        {
            creditPrice = 268;
        }
        
               
        
        
               
        
        if (CreditHours > 16)
        {
            CreditHours = 16;
        }
        tuition = creditPrice * CreditHours;
        total = activityFee + campusAccess + techFee + tuition;
        if (aid2.toUpperCase().equals("YES"))
        {
           total = 0;
        }
        
      
        try {
            print(name2, sinPluCla, aid2, classData, creditNum, classes2 ,activityFee, campusAccess, techFee, tuition, total);
        } catch (IOException ex) {
            Logger.getLogger(MyBill_Group.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void getName(String name4){
        name2 = name4;
    }
    public static void getAid(String aid4){
        aid2 = aid4;
    }
    public static void getClasses(Double classes4){
        classes2 = classes4;
    }
    public static void getState(String state4){
        state2 = state4;
    }
    
    public static void SetFormInfo(String className, double creditHours){
        ClassName = className;
        CreditHours += creditHours;
    }
    
    public static void print(String name2,String sinPluCla,String aid2, String classData,int creditNum, double classes2 , int activityFee,int campusAccess,int techFee,double tuition, double total) throws IOException{
        PrintWriter outputfile = new PrintWriter(name2+"Tuition.txt", "UTF-8");
        outputfile.println("Hello "+ name2 + ",\n"
                +"You're taking "+classes2+" "+ sinPluCla +"\n\n" +
                "Your total credit hours is " + creditNum + "\n" +
                "A break down of your total " + "\n" +
                "Activity Fee $" + activityFee + "\n" +
                "Camputs Access $" + campusAccess +"\n" +
                "Tech Fee $" + techFee +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid " + aid2 + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData);
        outputfile.close();
    }   
}