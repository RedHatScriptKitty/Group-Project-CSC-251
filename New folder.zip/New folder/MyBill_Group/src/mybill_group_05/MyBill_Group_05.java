/*
9/7/22 update
Noah kolb
 */
package mybill_group_05;

import javax.swing.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyBill_Group_05
{
    public static void main(String[] args)
    {
        String studentName, creditInput,tuitionType,classInput, financialAid,financialAidNum,classData="\n", sinPluCla="class"/*test*/;
        int numClasses = 0, counter, creditNum=0, creditPrice = 0, creditDisplay=0, data=0, fullCov=0;
        double total, tuition, financialAidparse=0;
        //boolean fullCov=false;
        //classes
        String[] classChoice = new String[18];
        classChoice[0] = "CSC-121";
        classChoice[1] = "CSC-134";
        classChoice[2] = "CSC-151";
        classChoice[3] = "CSC-218";
        classChoice[4] = "CSC-234";
        classChoice[5] = "CSC-221";
        classChoice[6] = "CSC-251";
        classChoice[7] = "CSC-253";
        classChoice[8] = "DBA-110";
        classChoice[9] = "DBA-125";
        classChoice[10] = "CTI-110";
        classChoice[11] = "CTI-120";
        classChoice[12] = "CTI-140";
        classChoice[13] = "CTI-141";
        classChoice[14] = "CTS-115";
        classChoice[14] = "CIS-110";
        classChoice[15] = "CIS-111";
        classChoice[16] = "CIS-113";
        classChoice[17] = "CIS-115";
        String[] stateType = new String[2];
        stateType[0] = "in state";
        stateType[1] = "out of state";
        /*constant values*/
        double activityFee = 35, campusAccess = 15, techFee = 16;
        studentName = JOptionPane.showInputDialog("Please enter your name");
        
        int n = JOptionPane.showConfirmDialog(  
                null,
                "Are you receiving Financial Aid?" ,
                "",
                JOptionPane.YES_NO_OPTION);

      if(n == JOptionPane.YES_OPTION)
      {
          int l = JOptionPane.showConfirmDialog(  
                null,
                "Is your Financial Aid covering your whole tuition?" ,
                "",
                JOptionPane.YES_NO_OPTION);
          if(l == JOptionPane.YES_OPTION)
          {
            fullCov=1;
          }
          if (l == JOptionPane.NO_OPTION)
          {
            financialAidNum= JOptionPane.showInputDialog("How much financial aid are you receiving?");
            financialAidparse = Integer.parseInt(financialAidNum);
            fullCov=0;
          }
      }
      else 
      {
          fullCov=0;
      }
        
        
        /*financialAid= JOptionPane.showInputDialog("Are you receiving Financial Aid?");       
        if (financialAid.toUpperCase().equals("YES"))
        {
            financialAidNum= JOptionPane.showInputDialog("How much financial aid are you receiving?");
            financialAidparse = Integer.parseInt(financialAidNum);
        }
        */
        // this returns type Object (JOptionPane javadocs)
        tuitionType = JOptionPane.showInputDialog(null, "Are you in-state or out-of-state?",
                "Selection", JOptionPane.PLAIN_MESSAGE, null, stateType, "in state").toString();

        if (tuitionType.equals("in state"))
        {
            creditPrice = 76;
        }
        else
        {
            creditPrice = 268;
        }
        
        
        
        try{
            classInput = JOptionPane.showInputDialog("How many classes will you take this semester?");         
            numClasses = Integer.parseInt(classInput);
            if (numClasses > 1)
            {sinPluCla = "classes";
            }
            else if (numClasses <= 1)
            {sinPluCla = "class";
            }
            while (data != numClasses)
            {
            classData = classData + JOptionPane.showInputDialog(null, "Choose your class", "Class Selection", JOptionPane.QUESTION_MESSAGE, null, classChoice, "CIS") + "\n";
            creditInput = JOptionPane.showInputDialog("How many credits is this class worth?");
            creditNum = creditNum + Integer.parseInt(creditInput);
            creditDisplay = creditNum;
            data = data+1;
            }
                
        }
        catch(Exception num){
            JOptionPane.showMessageDialog(null,"Please enter a number");
        }
        /*for (counter = 0; numClasses > counter; counter++)
        {
           test = JOptionPane.showInputDialog("enter number");
        }*/
        
        if (creditNum > 16)
        {
            creditNum = 16;
        }
        System.out.println(creditPrice);
        tuition = creditPrice * creditNum;
        if (fullCov ==1)
        {
             tuition = 0;
        }
        total = activityFee + campusAccess + techFee + tuition-financialAidparse;
        
        JOptionPane.showMessageDialog(null, studentName + " your total for this semester is $"+ String.format("%.2f", total));
        
        JOptionPane.showMessageDialog(null, "Hello "+ studentName + ",\n"
                +"You're taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "A break down of your total " + "\n" +
                "You have " + creditDisplay + " credit hours for this semester" + "\n" +
                "Activity Fee $" + String.format("%.2f", activityFee) + "\n" +
                "Campus Access $" + String.format("%.2f", campusAccess) +"\n" +
                "Tech Fee $" + String.format("%.2f", techFee) +"\n" +
                "Tuition $" + String.format("%.2f", tuition) + "\n" +
                "Financial Aid " + String.format("%.2f", financialAidparse) + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData);
      
        try {
            print(studentName, sinPluCla, financialAidparse, classData, creditDisplay, numClasses,activityFee, campusAccess, techFee, tuition, total);
        } catch (IOException ex) {
            Logger.getLogger(MyBill_Group_05.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void print(String studentName,String sinPluCla,double financialAidparse, String classData,int creditDisplay, int numClasses, double activityFee,double campusAccess,double techFee,double tuition, double total) throws IOException{
        PrintWriter outputfile = new PrintWriter(studentName+"Tuition.txt", "UTF-8");
        outputfile.println("Hello "+ studentName + ",\n"
                +"You're taking "+numClasses+" "+ sinPluCla +"\n\n" +
                "A break down of your total " + "\n" +
                "You're receiving" + creditDisplay + " credits for this semester" + "\n" +
                "Activity Fee $" + String.format("%.2f", activityFee) + "\n" +
                "Campus Access $" + String.format("%.2f", campusAccess) +"\n" +
                "Tech Fee $" + String.format("%.2f", techFee) +"\n" +
                "Tuition $" + tuition + "\n" +
                "Financial Aid " + financialAidparse + "\n" +
                        "____________________"+ "\n"+
                "Total $" + String.format("%.2f", total)+"\n"+classData);
        outputfile.close();
    }
  
    
}
